package com.softuni.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamWebApplication.class, args);
    }

}
